﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cibertec.WebApi.Test
{
    public static class ConfigSettings
    {
        public static string NorthwindConnectionString = "Server=.;Database=Northwind_Lite; Trusted_Connection=True;MultipleActiveResultSets=True";
    }
}
