﻿using Cibertec.Models;

namespace Cibertec.Repositories.Northwind
{
    public interface ISupplierRepository : IRepository<Supplier>
    {
    }
}
